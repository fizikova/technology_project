var searchData=
[
  ['_7edatabase_0',['~Database',['../class_database.html#a84d399a2ad58d69daab9b05330e1316d',1,'Database']]],
  ['_7eloginwindow_1',['~LoginWindow',['../class_login_window.html#a0c49fe788dcce29aa50e7d974e1ad158',1,'LoginWindow']]],
  ['_7emainwindow_2',['~MainWindow',['../class_main_window.html#ae98d00a93bc118200eeef9f9bba1dba7',1,'MainWindow']]],
  ['_7eregisterwindow_3',['~RegisterWindow',['../class_register_window.html#aaeb4a1dc724077a1c30dc96659371d42',1,'RegisterWindow']]],
  ['_7etaskwindow_4',['~TaskWindow',['../class_task_window.html#a11607c43214c828babb52265fa287275',1,'TaskWindow']]]
];
