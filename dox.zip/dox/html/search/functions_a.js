var searchData=
[
  ['taskwindow_0',['TaskWindow',['../class_task_window.html#addd531fe1ee3a3b45f545dc59401c8b4',1,'TaskWindow']]]
];
