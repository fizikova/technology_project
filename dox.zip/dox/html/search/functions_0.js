var searchData=
[
  ['chord_5fmethod_0',['chord_method',['../chord_8cpp.html#a2c35463823ccf700e92f318d6170d8f3',1,'chord_method(double(*f)(double), double a, double b, double tol):&#160;chord.cpp'],['../chord_8h.html#a0ce4d0d659a2fe4f96344915dcf4b1f8',1,'chord_method(double(*f)(double), double a, double b, double tol=1e-10):&#160;chord.cpp'],['../functionsforserver_8h.html#a0ce4d0d659a2fe4f96344915dcf4b1f8',1,'chord_method(double(*f)(double), double a, double b, double tol=1e-10):&#160;chord.cpp']]],
  ['chordmethod_1',['chordMethod',['../class_task_window.html#a4b50eaf032bc64c92c638e75dc7aa235',1,'TaskWindow']]],
  ['close_2',['close',['../class_database.html#ab89cb07242f0ab1d4058974bf3e7cf19',1,'Database']]]
];
