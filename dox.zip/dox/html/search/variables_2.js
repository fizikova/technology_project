var searchData=
[
  ['registerwindow_0',['registerWindow',['../class_main_window.html#ab5919214ed7eeb8c52a08c7bc7300cf7',1,'MainWindow']]]
];
