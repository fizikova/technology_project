var searchData=
[
  ['getinstance_0',['getInstance',['../class_database.html#aa04e547554cc34fa4b6c5a9390021eab',1,'Database']]]
];
