var searchData=
[
  ['functionsforserver_2ecpp_0',['functionsforserver.cpp',['../functionsforserver_8cpp.html',1,'']]],
  ['functionsforserver_2eh_1',['functionsforserver.h',['../functionsforserver_8h.html',1,'']]]
];
