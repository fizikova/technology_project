var searchData=
[
  ['loginwindow_0',['loginWindow',['../class_main_window.html#a5c013b5ca0c7819bf62613b828f4f503',1,'MainWindow']]]
];
