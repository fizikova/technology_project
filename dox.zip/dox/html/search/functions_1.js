var searchData=
[
  ['database_0',['Database',['../class_database.html#a4703c80e6969d33565ea340f768fdadf',1,'Database::Database()'],['../class_database.html#a83f8b6d2941a4aee50f225e08e97291c',1,'Database::Database(const Database &amp;)=delete']]]
];
