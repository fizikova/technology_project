var searchData=
[
  ['database_0',['Database',['../class_database.html',1,'Database'],['../class_database.html#a4703c80e6969d33565ea340f768fdadf',1,'Database::Database()'],['../class_database.html#a83f8b6d2941a4aee50f225e08e97291c',1,'Database::Database(const Database &amp;)=delete']]],
  ['database_2ecpp_1',['database.cpp',['../database_8cpp.html',1,'']]],
  ['database_2eh_2',['database.h',['../database_8h.html',1,'']]],
  ['db_3',['db',['../class_database.html#aea64d7d99483faec8f049cdd817bb693',1,'Database']]]
];
