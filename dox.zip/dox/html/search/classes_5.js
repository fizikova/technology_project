var searchData=
[
  ['taskwindow_0',['TaskWindow',['../class_task_window.html',1,'']]]
];
