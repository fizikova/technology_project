var searchData=
[
  ['taskwindow_0',['taskWindow',['../class_main_window.html#ae5b4e4fd90d2c62269521fd36c0c8562',1,'MainWindow']]]
];
