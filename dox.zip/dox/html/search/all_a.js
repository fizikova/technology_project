var searchData=
[
  ['saveuser_0',['saveUser',['../class_server.html#a3a488059930a87015e5e918cbf2ba35e',1,'Server']]],
  ['server_1',['Server',['../class_server.html',1,'Server'],['../class_server.html#aaf98d5194faee831c6340cc736b9b879',1,'Server::Server()']]],
  ['server_2ecpp_2',['server.cpp',['../server_8cpp.html',1,'']]],
  ['server_2eh_3',['server.h',['../server_8h.html',1,'']]],
  ['showloginwindow_4',['showLoginWindow',['../class_main_window.html#afde5d3401fd16f50d7f5c812bcc632f7',1,'MainWindow']]],
  ['showregisterwindow_5',['showRegisterWindow',['../class_main_window.html#a5a1eeb326fb9d539498dc66e8289d1ce',1,'MainWindow']]],
  ['showtaskwindow_6',['showTaskWindow',['../class_main_window.html#a5902a74a46441a6f204c5051801c6e8b',1,'MainWindow']]],
  ['some_5ffunction_7',['some_function',['../functionsforserver_8cpp.html#abe144a185e0333decb346e063c54298e',1,'some_function(double x):&#160;functionsforserver.cpp'],['../functionsforserver_8h.html#abe144a185e0333decb346e063c54298e',1,'some_function(double x):&#160;functionsforserver.cpp']]]
];
