var searchData=
[
  ['db_0',['db',['../class_database.html#aea64d7d99483faec8f049cdd817bb693',1,'Database']]]
];
